package com.examen.examenDH;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenDhApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenDhApplication.class, args);
	}

}
